# aulaReforco

# Hoje aprendemos muitas coisas